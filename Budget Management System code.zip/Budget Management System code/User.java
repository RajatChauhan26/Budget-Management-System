public class User {
    String username;
    String hashedPassword;
    String role;
    String email;
    String phoneNumber;

    public User(String username, String hashedPassword, String role, String email, String phoneNumber) {
        this.username = username;
        this.hashedPassword = hashedPassword;
        this.role = role;
        this.email = email;
        this.phoneNumber = phoneNumber;
    }
}
