import java.util.*;

public class AuthenticationManager {
    private final Map<String, User> users = new HashMap<>();

    public AuthenticationManager() {
        // Preload users
        users.put("member1", new User("member1", hashPassword("password123"), "member", "member1@oracle.com", "1234567890"));
        users.put("manager", new User("manager", hashPassword("Manager@1234"), "manager", "manager@oracle.com", "1122334455"));
    }

    public static String hashPassword(String password) {
        return Integer.toString(password.hashCode());
    }

    public User authenticate(String username, String password) {
        User user = users.get(username);
        if (user != null && user.hashedPassword.equals(hashPassword(password))) {
            return user;
        }
        return null;
    }

    public void registerUser(String username, String password, String role, String email, String phoneNumber) {
        if (users.containsKey(username)) {
            System.out.println("Username already exists. Please try a different username.");
            return;
        }
        users.put(username, new User(username, hashPassword(password), role, email, phoneNumber));
        System.out.println("User registered successfully!");
    }

    public boolean validatePassword(String password) {
        if (password.length() < 8) return false;
        boolean hasUpperCase = false;
        boolean hasSpecialChar = false;
        boolean hasDigit = false;

        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c)) hasUpperCase = true;
            if (!Character.isLetterOrDigit(c)) hasSpecialChar = true;
            if (Character.isDigit(c)) hasDigit = true;
        }

        return hasUpperCase && hasSpecialChar && hasDigit;
    }

    public boolean validatePhoneNumber(String phoneNumber) {
        return phoneNumber.matches("\\d+");
    }

    public void resetPassword(String username, String newPassword) {
        User user = users.get(username);
        if (user != null) {
            user.hashedPassword = hashPassword(newPassword);
            System.out.println("Password reset successfully!");
        } else {
            System.out.println("Username not found!");
        }
    }
}
