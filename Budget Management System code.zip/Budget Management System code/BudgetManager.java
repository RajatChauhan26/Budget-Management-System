import java.util.*;

public class BudgetManager {
    private final Map<String, Double> teamBudgets = new HashMap<>();
    private final Map<String, List<String>> teamExpenses = new HashMap<>();
    private final Map<String, Double> fundingRequests = new HashMap<>();

    public BudgetManager() {
        Arrays.asList("TeamA", "TeamB", "TeamC", "TeamD").forEach(team -> {
            teamBudgets.put(team, 1000.0);
            teamExpenses.put(team, new ArrayList<>());
        });
    }

    public void manageBudget(String team, double amount, boolean isSpending) {
        if (!teamBudgets.containsKey(team)) {
            System.out.println("Invalid team name.");
            return;
        }
        double newBudget = teamBudgets.get(team) + (isSpending ? -amount : amount);
        if (newBudget < 0 && isSpending) {
            System.out.println("Insufficient budget for this spending.");
        } else {
            teamBudgets.put(team, newBudget);
            if (isSpending) {
                teamExpenses.get(team).add("Spent $" + amount);
                System.out.println("Spending of $" + amount + " recorded for " + team + ".");
            } else {
                System.out.println("Budget for " + team + " updated to $" + teamBudgets.get(team));
            }
        }
    }

    public void requestFunding(String team, double amount) {
        if (!teamBudgets.containsKey(team)) {
            System.out.println("Invalid team name.");
            return;
        }
        fundingRequests.put(team, amount);
        System.out.println("Funding request of $" + amount + " for " + team + " has been sent to the manager.");
    }

    public void viewRecentExpenses(String team) {
        if (!teamExpenses.containsKey(team)) {
            System.out.println("Invalid team name.");
            return;
        }
        System.out.println("Recent expenses for " + team + ":");
        teamExpenses.get(team).forEach(System.out::println);
    }

    public void viewAllBudgets() {
        System.out.println("Team Budgets Overview:");
        teamBudgets.forEach((team, budget) -> System.out.println(team + ": $" + budget));
    }

    public void handleFundingRequests(String team, boolean approve) {
        if (!fundingRequests.containsKey(team)) {
            System.out.println("No funding request found for this team.");
            return;
        }
        double requestedAmount = fundingRequests.get(team);
        if (approve) {
            System.out.println("Funding of $" + requestedAmount + " approved for " + team);
            teamBudgets.put(team, teamBudgets.get(team) + requestedAmount);
        } else {
            System.out.println("Funding request for " + team + " declined.");
        }
        fundingRequests.remove(team);
    }
}
