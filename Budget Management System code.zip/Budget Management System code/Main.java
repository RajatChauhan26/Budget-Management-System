import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        AuthenticationManager authManager = new AuthenticationManager();
        BudgetManager budgetManager = new BudgetManager();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nWelcome to Oracle");
            System.out.println("1. Login as Member");
            System.out.println("2. Login as Manager");
            System.out.println("3. Register");
            System.out.println("4. Forget Password");
            System.out.println("5. Exit");
            System.out.print("Choose an option: ");
            
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    memberLogin(authManager, budgetManager, scanner);
                    break;
                case 2:
                    managerLogin(authManager, budgetManager, scanner);
                    break;
                case 3:
                    registerUser(authManager, scanner);
                    break;
                case 4:
                    forgetPassword(authManager, scanner);
                    break;
                case 5:
                    System.out.println("Exiting... Thank you for visiting Oracle!");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid option. Try again.");
            }
        }
    }

    private static void memberLogin(AuthenticationManager authManager, BudgetManager budgetManager, Scanner scanner) {
        System.out.print("\nEnter your username: ");
        String username = scanner.nextLine();
        System.out.print("Enter your password: ");
        String password = scanner.nextLine();

        User user = authManager.authenticate(username, password);

        if (user == null || !user.role.equals("member")) {
            System.out.println("Invalid username or password.");
            return;
        }

        handleMemberActions(budgetManager, scanner, username);
    }

    private static void managerLogin(AuthenticationManager authManager, BudgetManager budgetManager, Scanner scanner) {
        System.out.print("\nEnter manager username: ");
        String username = scanner.nextLine();
        System.out.print("Enter manager password: ");
        String password = scanner.nextLine();

        User user = authManager.authenticate(username, password);

        if (user == null || !user.role.equals("manager")) {
            System.out.println("Invalid username or password.");
            return;
        }

        handleManagerActions(budgetManager, scanner);
    }

    private static void registerUser(AuthenticationManager authManager, Scanner scanner) {
        System.out.print("Enter your username: ");
        String username = scanner.nextLine();
        System.out.print("Enter your password: ");
        String password = scanner.nextLine();
        
        // Validate password
        if (!authManager.validatePassword(password)) {
            System.out.println("Password must contain at least 2 uppercase letters, 1 special character, 1 digit, and be at least 8 characters long.");
            return;
        }

        System.out.print("Enter your role (member/manager): ");
        String role = scanner.nextLine();
        System.out.print("Enter your email: ");
        String email = scanner.nextLine();
        
        System.out.print("Enter your phone number: ");
        String phoneNumber = scanner.nextLine();
        
        // Validate phone number
        if (!authManager.validatePhoneNumber(phoneNumber)) {
            System.out.println("Phone number should only contain digits.");
            return;
        }

        authManager.registerUser(username, password, role, email, phoneNumber);
    }

    private static void forgetPassword(AuthenticationManager authManager, Scanner scanner) {
        System.out.print("Enter your username: ");
        String username = scanner.nextLine();
        
        System.out.print("Enter new password: ");
        String newPassword = scanner.nextLine();
        
        // Validate new password
        if (!authManager.validatePassword(newPassword)) {
            System.out.println("Password must contain at least 2 uppercase letters, 1 special character, 1 digit, and be at least 8 characters long.");
            return;
        }

        authManager.resetPassword(username, newPassword);
    }

    private static void handleMemberActions(BudgetManager budgetManager, Scanner scanner, String username) {
        while (true) {
            System.out.println("\nWelcome Member: " + username);
            System.out.println("1. View Team Budget");
            System.out.println("2. Add Spending");
            System.out.println("3. Request Funding");
            System.out.println("4. View Recent Expenses");
            System.out.println("5. Logout");
            System.out.print("Choose an option: ");
            
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter team name to view budget: ");
                    String team = scanner.nextLine();
                    budgetManager.manageBudget(team, 0, false); // Viewing budget doesn't change it
                    break;
                case 2:
                    System.out.print("Enter team name to add spending: ");
                    String teamToSpend = scanner.nextLine();
                    System.out.print("Enter amount to spend: ");
                    double amount = scanner.nextDouble();
                    scanner.nextLine(); // Consume newline
                    budgetManager.manageBudget(teamToSpend, amount, true);
                    break;
                case 3:
                    System.out.print("Enter team name to request funding: ");
                    String teamForFunding = scanner.nextLine();
                    System.out.print("Enter amount to request: ");
                    double fundingAmount = scanner.nextDouble();
                    scanner.nextLine(); // Consume newline
                    budgetManager.requestFunding(teamForFunding, fundingAmount);
                    break;
                case 4:
                    System.out.print("Enter team name to view recent expenses: ");
                    String teamForExpenses = scanner.nextLine();
                    budgetManager.viewRecentExpenses(teamForExpenses);
                    break;
                case 5:
                    System.out.println("Logging out...");
                    return;
                default:
                    System.out.println("Invalid option. Try again.");
            }
        }
    }

    private static void handleManagerActions(BudgetManager budgetManager, Scanner scanner) {
        while (true) {
            System.out.println("\nWelcome Manager");
            System.out.println("1. View All Budgets");
            System.out.println("2. Adjust Team Budget");
            System.out.println("3. View Funding Requests");
            System.out.println("4. Approve/Reject Funding Requests");
            System.out.println("5. Logout");
            System.out.print("Choose an option: ");
            
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    budgetManager.viewAllBudgets();
                    break;
                case 2:
                    System.out.print("Enter team name to adjust budget: ");
                    String team = scanner.nextLine();
                    System.out.print("Enter amount to adjust (positive for increase, negative for decrease): ");
                    double amount = scanner.nextDouble();
                    scanner.nextLine(); // Consume newline
                    budgetManager.manageBudget(team, amount, false);  // false = adjustment, not spending
                    break;
                case 3:
                    budgetManager.viewRecentExpenses("TeamA"); // Same logic for manager, for now.
                    break;
                case 4:
                    System.out.print("Enter team name to approve/reject funding: ");
                    String teamForApproval = scanner.nextLine();
                    System.out.print("Approve (true/false): ");
                    boolean approve = scanner.nextBoolean();
                    scanner.nextLine(); // Consume newline
                    budgetManager.handleFundingRequests(teamForApproval, approve);
                    break;
                case 5:
                    System.out.println("Logging out...");
                    return;
                default:
                    System.out.println("Invalid option. Try again.");
            }
        }
    }
}
